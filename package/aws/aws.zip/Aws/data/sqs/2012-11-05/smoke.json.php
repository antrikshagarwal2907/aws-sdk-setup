<?php
// This file was auto-generated from sdk-root/src/data/sqs/2012-11-05/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListQueues', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetQueueUrl', 'input' => [ 'QueueName' => 'fake_queue', ], 'errorExpectedFromService' => true, ], ],];
