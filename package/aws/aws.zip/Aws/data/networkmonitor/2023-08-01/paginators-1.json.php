<?php
// This file was auto-generated from sdk-root/src/data/networkmonitor/2023-08-01/paginators-1.json
return [ 'pagination' => [ 'ListMonitors' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'monitors', ], ],];
