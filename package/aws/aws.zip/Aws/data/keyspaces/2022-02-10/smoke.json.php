<?php
// This file was auto-generated from sdk-root/src/data/keyspaces/2022-02-10/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
