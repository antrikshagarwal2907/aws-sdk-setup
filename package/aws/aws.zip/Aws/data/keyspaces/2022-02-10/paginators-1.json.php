<?php
// This file was auto-generated from sdk-root/src/data/keyspaces/2022-02-10/paginators-1.json
return [ 'pagination' => [ 'ListKeyspaces' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'keyspaces', ], 'ListTables' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'tables', ], 'ListTagsForResource' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'tags', ], ],];
