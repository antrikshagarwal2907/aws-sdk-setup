<?php
// This file was auto-generated from sdk-root/src/data/sso/2019-06-10/paginators-1.json
return [ 'pagination' => [ 'ListAccountRoles' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'roleList', ], 'ListAccounts' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'accountList', ], ],];
