<?php
// This file was auto-generated from sdk-root/src/data/amplifyuibuilder/2021-08-11/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
