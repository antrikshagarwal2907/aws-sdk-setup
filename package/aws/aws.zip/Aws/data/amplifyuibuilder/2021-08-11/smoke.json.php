<?php
// This file was auto-generated from sdk-root/src/data/amplifyuibuilder/2021-08-11/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
