<?php
// This file was auto-generated from sdk-root/src/data/eventbridge/2015-10-07/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListRules', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeRule', 'input' => [ 'Name' => 'fake-rule', ], 'errorExpectedFromService' => true, ], ],];
